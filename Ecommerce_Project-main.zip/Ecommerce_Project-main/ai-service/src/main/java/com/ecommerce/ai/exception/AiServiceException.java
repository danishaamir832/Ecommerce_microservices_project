package com.ecommerce.ai.exception;

import org.springframework.http.HttpStatus;

public class AiServiceException extends RuntimeException {
    private final HttpStatus status;
    public AiServiceException(HttpStatus status, String message) { super(message); this.status = status; }
    public HttpStatus status() { return status; }
}
